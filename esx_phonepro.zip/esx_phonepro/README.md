# esx_phonepro
Professionelles Telefon-System für ESX Legacy mit:  - Polizei, Ambulanz, Mechaniker, Feuerwehr Dispatch - WhatsApp &amp; Twitter mit Persistenz - Kamera-App, Galerie, Selfie, Filter - Nummern-Sharing - PIN-Lockscreen, Hintergründe, Klingeltöne - Voice-Call Integration (pma-voice)
## Installation

1. MySQL Tabellen erstellen:
   ```sql
   -- siehe sql/esx_phonepro.sql
